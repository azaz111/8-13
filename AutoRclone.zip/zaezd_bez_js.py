from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os , math , time
from sys import argv
import json
import subprocess
from BIB_API import service_avtoriz , perenos_fails_list , spisok_fails_q ,new_drive , \
           spisok_fails_roditelya,createRemoteFolder,peremesti_v_odnu , drive_ls ,_is_success



successful = []

service = service_avtoriz()
service2 = service_avtoriz('v2')

if len(drive_ls(service)) == 1 :
   s_iddrive=drive_ls(service)[0]['id']
else:
   print( 'НЕ пойму какого хрена вижу больше одного диска !  ') 
   s_iddrive=input('Укажи в ручную : ')

n=int(input('С какого диска начинаем :'))

sp_paps=spisok_fails_q(service,s_iddrive,"mimeType = 'application/vnd.google-apps.folder' and name contains '.d'")
print(' НУжных папок : ' + str(len(sp_paps)))
if len(sp_paps) == 100:
    print('Папок то что нужно')
else:
    print('ВЫ уверены в продолжении папок не хватает')
    input('Да конечно "1" :')
print('Создаю диски')
id_spis=[]
ls_files={}

pap_bibl={}
for qqq in sp_paps:
    #print(pap_bibl)
    #print('-----------------------------')
    pap_bibl[qqq['name'][:-4]] = qqq['id'] #Создаем библиотеку папок
print(pap_bibl)    

drive_bibl={}
for qqq in drive_ls(service):
    #print(qqq)
    drive_bibl[qqq['name']] = qqq['id'] #Создаем библиотеку дисков
print(drive_bibl)


n=n-1
while n != len(sp_paps):
    n+=1
    id_nd = drive_bibl[str(n)]  
    file = service.files().get(fileId=pap_bibl[str(n)], supportsAllDrives=True, fields='parents').execute()
    previous_parents = ",".join(file.get('parents'))

    try:
        print('Перекидываю ' + str(n))
        file = service.files().update(fileId=pap_bibl[str(n)],
                                      addParents=id_nd,
                                      supportsAllDrives=True, 
                                      removeParents=previous_parents, fields='id, parents').execute()
    except HttpError as err: 
        if err.resp.get('content-type', '').startswith('application/json'):
            reason = json.loads(err.content).get('error').get('errors')[0].get('reason')
            print('ОШИБКА : ' + reason)
            print('Ждем дополнительные 10 секунд')
            time.sleep(10) 
            n=n-1