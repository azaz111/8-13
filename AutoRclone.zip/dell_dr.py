from __future__ import print_function
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import os
from random import randint
import subprocess
import argparse
import fileinput
import time
import threading
from multiprocessing.pool import ThreadPool
import concurrent.futures
from sys import argv

delit = argv[1]

# If modifying these scopes, delete the file token.json.
SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]

def folder_po_id(delit,service):
    folder_ids = service.files().list(corpora='drive', 
                                      includeItemsFromAllDrives=True, 
                                      supportsAllDrives=True,
                                      q="mimeType = 'application/vnd.google-apps.folder'", 
                                      driveId=delit, fields="nextPageToken, files(id,name)").execute() # Список папок на диске
 
    folder_idss = folder_ids.get('files')
    folder_ids = folder_idss[0]
    #folder_id = folder_ids.get('id') # айди папки с плотами  = folder_ids.get('id') # айди папки с плотами 
    #folder_name = folder_ids.get('id') # айди папки с плотами 
    for i in folder_idss:
        folder_id = i.get('id') # айди папки с плотами  = folder_ids.get('id') # айди папки с плотами 
        folder_name = i.get('name') # айди папки с плотами 
        print('id : '+ folder_id +'   Name :'+ folder_name )
    return folder_id

def createRemoteFolder(service2, folderName, parentID = None):
    # Create a folder on Drive, returns the newely created folders ID 
    print(f'vzghu imya {folderName}')
    body = {'title': folderName,
      'mimeType': "application/vnd.google-apps.folder"
    }
    if parentID:
        body['parents'] = [{'id': parentID}]
    root_folder = service2.files().insert(supportsTeamDrives=True , body = body ).execute() 
    return root_folder['id']

def perenos_fails(new_file,id_foldnazna,service):
   file = service.files().get(fileId=new_file, supportsAllDrives=True, fields='parents').execute()
   previous_parents = ",".join(file.get('parents')) 
   file = service.files().update(fileId=new_file,
                                 addParents=id_foldnazna,
                                 supportsAllDrives=True, 
                                 removeParents=previous_parents, fields='id, parents').execute()# перемещаем в бекапную папку 


def poisk_or_sozd(service,folder_idsm,name_poisk):
    razn = 0
    for sps in folder_idsm:  ## Если надо создали диск "разн" если есть то взяли айди
       name_prov = sps.get('name')
       if name_prov == name_poisk :
          razn_grive_id = sps.get('id')
          razn = 1
    if razn == 1 :
        print("drive - true = " + razn_grive_id)
    else:
        razn_grive = service.teamdrives().create(requestId=randint(1,9999999), body={"name":f"{name_poisk}"}).execute() #создать новый диск 
        razn_grive_id = razn_grive['id']
        process = subprocess.Popen(['python3', 'masshare.py', '-d', f'{razn_grive_id}'])
        process.wait()
    return razn_grive_id

def spisok_fails(s_iddrive,service,colvo=None): # Список всех файлов на диске в виде айди 
    if colvo:
        pass
    else:
        colvo=1000
    file_spis=[]
    page_token = None
    while True:
        response = service.files().list(spaces='drive',
                                        corpora='drive',
                                        includeItemsFromAllDrives=True,
                                        supportsAllDrives=True,
                                        driveId=s_iddrive,
                                        fields='nextPageToken, files(id, name)',
                                        pageToken=page_token).execute() 
    
        for file in response.get('files', []):
            # Изменение процесса
            file_spis.append(file)
            # print(file.get('name'), file.get('id'))
        page_token = response.get('nextPageToken', None)
        if page_token is None:
            break     
    return file_spis[:colvo]


def main():
    filed_conf_rclone = "/root/.config/rclone/rclone.conf"
    """Shows basic usage of the Drive v3 API.
    Prints the names and ids of the first 10 files the user has access to.
    """
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    service = build('drive', 'v3', credentials=creds)

    try:
        folder_po_id(delit,service)
        print('vvedi folder')
        dir_id=input()
      
        service.files().delete(fileId=dir_id,supportsAllDrives=True).execute()
    except:
        print("нет папки")
    print('vvedi drive')
    dir_id=input()   

    service.drives().delete(driveId=dir_id).execute()
               
if __name__ == '__main__':
    main()